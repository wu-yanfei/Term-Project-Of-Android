# 小而美，集成下面两位大神的代码
# https://github.com/AlpHerk/NjtechAutoLogin
# https://github.com/chimeElm/captchaIdentify

# 南工大酷安交流群@北巷

USR = "XXXXXXXXXX"  # 填入自己的学号
PWD = "XXXXXXXXXXX"  # 填入自己的密码
COP = "中国移动"  # 中国移动/中国电信


import re
import requests
import threading
from time import sleep
from PIL import Image
from number import numberLs


requests.packages.urllib3.disable_warnings()


class AutoLogin():
    """ 参数：学号、密码、运营商
    """

    def __init__(self, usr, pwd, brand):
        self.username = usr
        self.password = pwd
        self.brancorp = brand
        if self.brancorp == '中国移动':
            self.bandabbr = '@cmcc'
        elif self.brancorp == '中国电信':
            self.bandabbr = '@telecom'

    def postLogin(self):
        """ 校园网认证核心代码 """
        resp = requests.get(url=LOGINURL, headers=PSTHEADER, verify=False)
        res2 = requests.get(url=CAPTCHURL, cookies=resp.cookies, verify=False)

        with open("capt.jpg", 'wb') as fp:
            fp.write(res2.content)
        capt = self.captGet()


        lt = re.search('lt\" value=\"(.*?)\"', resp.text).groups()[0]
        exe = re.search('execution\" value=\"(.*?)\"', resp.text).groups()[0]
        form = {
            "username": self.username, "password": self.password,
            "channelshow": self.brancorp, "channel": self.bandabbr,
            "lt": lt, "execution": exe,
            "_eventId": "submit", "captcha": capt}
        requests.post(url=LOGINURL, headers=PSTHEADER, data=form, cookies=resp.cookies, verify=False)

    def loginThread(self):
        threads = []
        threads.append(threading.Thread(target=self.postLogin))
        threads.append(threading.Thread(target=self.__progressBar))
        for t in threads: t.start()
        for t in threads: t.join()

    def __progressBar(self):
        for i in range(11):
            print('\r正在连接：{0} {1}%'.format('▉▉' * i, (i * 10)), end='');
            sleep(0.05)

    def isConnectNet(self):
        try:
            requests.get("https://www.baidu.com", headers=PSTHEADER, timeout=2, verify=False)
        except:
            return False
        return True

    def captGet(self):
        image = Image.open(f'capt.jpg').resize((40, 19))

        pixelLs = [i[0] * 0.299 + i[1] * 0.587 + i[2] * 0.114 for i in image.getdata()]
        pixelLs = [255 if i > 150 else 0 for i in pixelLs]
        pixelLs_1, pixelLs_2, pixelLs_3, pixelLs_4 = [], [], [], []
        for i in range(760):
            if 2 <= i % 40 < 12:
                pixelLs_1.append(pixelLs[i])
            if 11 <= i % 40 < 21:
                pixelLs_2.append(pixelLs[i])
            if 20 <= i % 40 < 30:
                pixelLs_3.append(pixelLs[i])
            if 29 <= i % 40 < 39:
                pixelLs_4.append(pixelLs[i])
        lossLs_1, lossLs_2, lossLs_3, lossLs_4 = [], [], [], []
        for numberLi in numberLs:
            loss_1, loss_2, loss_3, loss_4 = 0, 0, 0, 0
            for i in range(190):
                loss_1 += (pixelLs_1[i] - numberLi[i]) ** 2
                loss_2 += (pixelLs_2[i] - numberLi[i]) ** 2
                loss_3 += (pixelLs_3[i] - numberLi[i]) ** 2
                loss_4 += (pixelLs_4[i] - numberLi[i]) ** 2
            lossLs_1.append(loss_1)
            lossLs_2.append(loss_2)
            lossLs_3.append(loss_3)
            lossLs_4.append(loss_4)
        res = ''.join([str(i.index(min(i)) + 1) for i in [lossLs_1, lossLs_2, lossLs_3, lossLs_4]])
        print("   识别的验证码：", res)

        return res

    def toConnect(self):
        # 第一次进行快速认证
        self.loginThread()

        # 进行稳定性检测
        while True:
            if self.isConnectNet():
                print("\n网络连通，请畅享网络~~~")
                sleep(5)  # 间隔多少秒检测一次网络
            else:
                print("\n网络断开，正在重新认证...~")
                self.loginThread()




################## 全局常量 请勿修改 ##################
LOGINURL = "https://u.njtech.edu.cn/cas/login?service=https://u.njtech.edu.cn/oauth2/authorize?client_id=Oe7wtp9CAMW0FVygUasZ&response_type=code&state=njtech&s=f682b396da8eb53db80bb072f5745232"
CAPTCHURL = "https://u.njtech.edu.cn/cas/captcha.jpg"
USERAGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Safari/605.1.15"
PSTHEADER = {
    "Host": "u.njtech.edu.cn",
    "Content-Type": "application/x-www-form-urlencoded",
    "Origin": "https://u.njtech.edu.cn",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "User-Agent": USERAGENT,
    "Referer": LOGINURL,
    "Accept-Language": "zh-CN,zh-Hans;q=0.9",
}  ############### 全局常量 请勿修改 ###################

if __name__ == '__main__':
    login = AutoLogin(USR, PWD, COP)

    login.toConnect()
